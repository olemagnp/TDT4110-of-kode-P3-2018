
pi = 3.14
r = 1
h = 8

v = pi * (r ** 2) * (h / 3)

print(v)
