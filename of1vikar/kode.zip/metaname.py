
creator = input("Hvem har laget meg? ")

# print(f"{creator} har laget dette programmet.")
print(creator, "har laget dette programmet.")
