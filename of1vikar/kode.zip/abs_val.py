
x = float(input("Tall 1: "))
y = float(input("Tall 2: "))

abs_diff = abs(x - y)

print(abs_diff)
