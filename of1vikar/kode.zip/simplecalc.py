
x = input("Tall1: ")
y = float(input("Tall2: "))

x = float(x)

product = x * y
print(f"{x} * {y} = {product}")
